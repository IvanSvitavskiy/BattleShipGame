from player import Player
import pygame


def main():
    Player().play()


main()
pygame.quit()
