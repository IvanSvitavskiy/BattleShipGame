block_size = 50
left_margin = 200
upper_margin = 100
letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
letters_dict = {'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8,
                'I': 9, 'J': 10}
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
size = (left_margin + 29 * block_size, upper_margin + 15 * block_size)
players = ['1', '2']
FPS = 60
